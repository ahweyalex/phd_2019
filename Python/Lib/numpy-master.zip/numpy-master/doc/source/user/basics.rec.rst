.. _structured_arrays:

*****************
Structured arrays 
*****************

.. automodule:: numpy.doc.structured_arrays

Recarray Helper Functions
*************************

.. automodule:: numpy.lib.recfunctions
    :members:
